/**
 * ESSE SISTEMA DE PROTOTYPES FOI UMA GAMBIARRA FEITA POR PURA CURIOSIDADE PELOS SEGUINTES MEMBROS:
 * IDEALIZADOR DOS PROTOTYPES: JackSkelt#3063 - 904891162362519562
 * ESCRITA & CONSTRUÇÃO: Rody#1000 - 451619591320371213
 * IDEALIZADOR DO "clientPermissions": Seeker#2083 - 750714601284304986
 */

import('./prototypes/Array.js')
import('./prototypes/Date.js')
import('./prototypes/Guild.js')
import('./prototypes/GuildMember.js')
import('./prototypes/Number.js')
import('./prototypes/String.js')
import('./prototypes/Discord.js')
import('./prototypes/Roles.js')
import('./prototypes/User.js')
import('./prototypes/UserManager.js')
import('./prototypes/GuildManager.js')