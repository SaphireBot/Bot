export default {
    BaseDomain: "https://saphire.discloud.app",
    General: "/",
    MercadoPagoWebhook: "/MercadoPagoComprovante",
    TopGG: "/topgg",
    Database: "/database",
    DiscloudPort: 8080
}