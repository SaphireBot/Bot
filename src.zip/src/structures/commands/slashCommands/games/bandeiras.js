// import flag from '../../functions/bandeiras/class.bandeiras.js'
// import { ApplicationCommandOptionType } from 'discord.js'

// export default {
//     name: 'bandeiras',
//     description: '[games] Um simples jogo de adivinhar as bandeiras',
//     type: 1,
//     dm_permission: false,
//     options: [
//         {
//             name: 'start',
//             description: '[games] Comece um novo jogo de adivinhar bandeiras',
//             type: ApplicationCommandOptionType.Subcommand
//         }
//     ],
//     async execute({ interaction, emojis: e }) {

//         // const { options } = interaction
//         // const subCommand = options.getSubcommand()

//         // if (subCommand === 'start') return new flag(interaction).game()
//     }
// }