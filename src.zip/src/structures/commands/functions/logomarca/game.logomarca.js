export default async (interaction) => {

    return await interaction.reply({
        content: 'ok',
        ephemeral: true
    })

}