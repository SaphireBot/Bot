export default async function (error, origin) {
    return console.log(error, origin)
}