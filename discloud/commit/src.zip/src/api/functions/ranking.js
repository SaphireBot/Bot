import { User } from "../../classes/database/Models.js"

export default async () => await User.find({})