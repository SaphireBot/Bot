/**
 * ESSE SISTEMA DE PROTOTYPES FOI UMA GAMBIARRA FEITA POR PURA CURIOSIDADE PELOS SEGUINTES MEMBROS:
 * IDEALIZADOR DOS PROTOTYPES: JackSkelt#3063 - 904891162362519562
 * ESCRITA & CONSTRUÇÃO: Rody#1000 - 451619591320371213
 * IDEALIZADOR DO "clientPermissions": Seeker#2083 - 750714601284304986
 */

import('./prototypes/Array.prototypes.js')
import('./prototypes/Date.prototypes.js')
import('./prototypes/Guild.prototypes.js')
import('./prototypes/GuildMember.prototypes.js')
import('./prototypes/Number.prototypes.js')
import('./prototypes/String.prototypes.js')
import('./prototypes/Discord.prototypes.js')
import('./prototypes/Roles.prototypes.js')
import('./prototypes/User.prototypes.js')
import('./prototypes/UserManager.prototypes.js')
import('./prototypes/GuildManager.prototypes.js')